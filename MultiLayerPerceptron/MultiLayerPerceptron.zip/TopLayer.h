#ifndef TOPLAYER_H
#define TOPLAYER_H
#include"Layer.h"


class TopLayer : public Layer{
private:
	int actual;
public:
	TopLayer() : Layer(10, 10){}; 
	// not sure yet! depends on how the backprop is designed and how the number of neuronsa are set.
	void forward(Layer* prevLayer);
	void backward(Layer* prevLayer);
	void set_y();
};

#endif