#include "Net.h"

using namespace std;

Net::Net(vector<int> layerInfo, int miniBatchSize, double eta){
	// Top layer will always have 10 outputs and no weight/bias in it.
	// so it is not counted in the layerInfo vector
	this->numLayer = layerInfo.size() + 1;
	this->layerInfo = layerInfo;
	this->miniBatchSize = miniBatchSize;
	this->eta = eta;
	if (numLayer < 3) {
		// There should at least be an input layer, an output layer and a mid layer
		exit(EXIT_FAILURE);
	}
	// initialize the input layer
	this->inputLayer = new InputLayer(layerInfo[0]);
	percepNet.push_back(inputLayer);
	// all hidden layers
	Layer* layerPtr;
	for (int i = 1; i < numLayer - 1; i++){
		layerPtr = new Layer(layerInfo[i - 1], layerInfo[i]);
		percepNet.push_back(layerPtr);
	}
	// output layer
	this->topLayer = new TopLayer();
	percepNet.push_back(topLayer);

}

void Net::back_propagation(){
	// first compute the 10 class loss using the overloaded backward()
	topLayer->backward(percepNet[numLayer-2]);
	for (int i = numLayer - 2; i > 0; i--){
		// start from the last hidden layer, to the first hidden layer
		percepNet[i]->backward(percepNet[i+1], percepNet[i-1]);
	}
}

void Net::feed_forward(){
	for (int i = 1; i < numLayer - 1; i++){
		// all the way from the first hidden layer to the top layer
		percepNet[i]->forward(percepNet[i - 1]);
	}
}

void Net::update_paras(){
	for (int i = 1; i < numLayer - 2; i++){ 
		percepNet[i]->update_weight(eta, miniBatchSize);
	}
}

void Net::SGD_minibatch(vector<vector<double> > miniBatch){
	for (int i = 0; i < miniBatch.size(); i++){
		inputLayer->set_activation(miniBatch[i]);
		feed_forward();
		back_propagation();
	}
	// update the weight after all instances in minibatch are used
	update_paras();
}