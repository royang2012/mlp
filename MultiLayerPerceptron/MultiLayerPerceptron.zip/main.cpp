#include <iostream>
#include <vector>
#include "Net.h"
#include "mnist_reader_less.hpp"
using namespace std;
void main(){
	vector<int> layerInfo;
	layerInfo.push_back(10); 
	layerInfo.push_back(10);
	layerInfo.push_back(10);
	Net* network = new Net(layerInfo, 64, 0.01);

	vector<vector<uint8_t> > trainImgs = mnist::read_training_images();

	int waste;
	cin >> waste;
}