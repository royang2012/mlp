#ifndef NET_H
#define NET_H

#include"Layer.h"
#include"InputLayer.h"
#include"TopLayer.h"
#include<vector>
#include<string>
using namespace std;
class Net{
private:
	int numLayer;
	int miniBatchSize;
	double eta;
	vector<int> layerInfo;
	InputLayer* inputLayer;
	vector<Layer*> percepNet;
	TopLayer* topLayer;

public:
	Net(vector<int> layerInfo, int miniBatchSize, double eta);
	//void setup();
	void SGD_minibatch(vector<vector<double> > miniBatch);
	void train(int numEpoch);
	void feed_forward();
	void back_propagation();
	void update_paras();
};

#endif